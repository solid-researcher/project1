# research-spl-poc
Run `python3 preprocessor.py contracts/src/Counter.sol`.